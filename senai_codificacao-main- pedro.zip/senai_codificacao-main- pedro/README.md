# senai_codificacao

Neste projeto utilizei HTML5, CSS3 com Bootstrap 5 e JavaScript com jQuerry.

A atividade a princípio consiste no desenvolvimento de duas paginas (index e login) para uma loja vitual do segmento gamer.
